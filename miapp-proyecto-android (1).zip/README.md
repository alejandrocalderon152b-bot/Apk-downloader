# Mi App

Proyecto Android generado con Forja APK. Es un contenedor WebView que carga tu web desde
`app/src/main/assets/www/` (se sirve en https://appassets.androidplatform.net, así que fetch,
localStorage y las rutas relativas funcionan igual que en un servidor).

## Compilar el APK

### Opcion A: GitHub Actions (sin instalar nada)
1. Sube este proyecto a un repositorio de GitHub (o sube el ZIP tal cual y añade el archivo
   `.github/workflows/build-apk.yml`).
2. Abre la pestaña Actions. El flujo "Compilar APK" se ejecuta solo y tarda unos 3 minutos.
3. Descarga el .apk desde Releases, o el artefacto `app-debug-apk` de la ejecución.

### Opcion B: Android Studio
1. File > Open y elige esta carpeta.
2. Espera a que termine Gradle Sync.
3. Build > Build APK(s). El archivo queda en `app/build/outputs/apk/debug/`.

### Opcion C: terminal
Con JDK 17, Android SDK 34 y Gradle 8.7: `gradle assembleDebug`.

## Cambiar la web
Edita `app/src/main/assets/www/index.html` y los archivos que la acompañan, y vuelve a compilar.
Usa rutas relativas (`css/estilo.css`), no absolutas (`/css/estilo.css`).

## Funciones nativas desde JavaScript
```js
AndroidApp.toast("Hola");          // mensaje breve
AndroidApp.vibrate(80);            // milisegundos
AndroidApp.share("Texto");         // hoja de compartir
AndroidApp.openUrl("https://...");  // abre el navegador
AndroidApp.exit();                 // cierra la app
AndroidApp.version();              // "1.0.0"
```
Comprueba `window.AndroidApp` antes de usarlas, para que tu web siga funcionando en un navegador.

## Depurar
En un APK de depuración puedes inspeccionar la web desde Chrome del ordenador en `chrome://inspect`.

## Publicar en Google Play
Este APK está firmado con la clave de depuración. Para Google Play crea tu propia clave de firma
y genera un paquete firmado (Build > Generate Signed Bundle / APK).
