package com.ejemplo.miapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

/** Generado por Forja APK. Tu web esta en app/src/main/assets/www/ */
@SuppressWarnings("deprecation")
public class MainActivity extends Activity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String THEME_COLOR = "#0E7A4D";
    private static final String SPLASH_COLOR = "#FFFFFF";
    private static final String APP_VERSION = "1.0.0";

    private static final boolean OPEN_EXTERNAL = true;
    private static final boolean PULL_REFRESH = true;
    private static final boolean DOUBLE_BACK_EXIT = true;
    private static final boolean ALLOW_ZOOM = false;
    private static final boolean SHOW_PROGRESS = true;
    private static final boolean JS_BRIDGE = true;
    private static final boolean IMMERSIVE = false;
    private static final boolean KEEP_ON = false;
    private static final boolean ALLOW_CAMERA = false;
    private static final boolean ALLOW_MIC = false;
    private static final boolean ALLOW_GEO = false;
    private static final boolean ALLOW_DOWNLOADS = true;

    private static final int FILE_REQ = 4101;
    private static final int PERM_REQ = 4102;
    private static final int GEO_REQ = 4103;

    private WebView web;
    private SwipeRefreshLayout swipe;
    private ProgressBar progress;
    private WebViewAssetLoader loader;
    private WebChromeClient chrome;

    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPerm;
    private String[] pendingWebRes;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCb;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private int baseUiFlags = 0;
    private long lastBack = 0;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        int bar = Color.parseColor(THEME_COLOR);
        int splash = Color.parseColor(SPLASH_COLOR);
        Window w = getWindow();
        if (KEEP_ON) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(bar);
        w.setNavigationBarColor(splash);
        int flags = 0;
        if (Build.VERSION.SDK_INT >= 23 && ColorUtils.calculateLuminance(bar) > 0.5) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26 && ColorUtils.calculateLuminance(splash) > 0.5) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        baseUiFlags = flags;
        applyUi(IMMERSIVE);

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(splash);

        web = new WebView(this);
        web.setBackgroundColor(splash);
        swipe = new SwipeRefreshLayout(this);
        swipe.setEnabled(PULL_REFRESH);
        swipe.setOnRefreshListener(() -> web.reload());
        swipe.setOnChildScrollUpCallback((parent, child) -> web.getScrollY() > 0);
        swipe.addView(web);
        root.addView(swipe, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3));
        plp.gravity = Gravity.TOP;
        root.addView(progress, plp);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(ALLOW_ZOOM);
        s.setBuiltInZoomControls(ALLOW_ZOOM);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setGeolocationEnabled(ALLOW_GEO);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        // Permite depurar la web con chrome://inspect en builds de depuracion
        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        if (JS_BRIDGE) web.addJavascriptInterface(new Bridge(), "AndroidApp");

        if (ALLOW_DOWNLOADS) {
            web.setDownloadListener((url, ua, cd, mime, len) -> {
                try {
                    if (url.startsWith("blob:") || url.startsWith("data:")) {
                        toast("Este tipo de descarga no esta soportado");
                        return;
                    }
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    String name = URLUtil.guessFileName(url, cd, mime);
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) r.addRequestHeader("Cookie", cookies);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                    toast("Descargando...");
                } catch (Exception e) {
                    toast("No se pudo descargar el archivo");
                }
            });
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return route(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return route(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                swipe.setRefreshing(false);
                progress.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError();
            }
        });

        chrome = new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (!SHOW_PROGRESS) return;
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    List<String> grant = new ArrayList<>();
                    List<String> need = new ArrayList<>();
                    for (String res : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && ALLOW_CAMERA) {
                            grant.add(res);
                            need.add(Manifest.permission.CAMERA);
                        } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && ALLOW_MIC) {
                            grant.add(res);
                            need.add(Manifest.permission.RECORD_AUDIO);
                        }
                    }
                    if (grant.isEmpty()) {
                        request.deny();
                        return;
                    }
                    List<String> missing = new ArrayList<>();
                    for (String p : need) {
                        if (ContextCompat.checkSelfPermission(MainActivity.this, p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
                    }
                    String[] granted = grant.toArray(new String[0]);
                    if (missing.isEmpty()) {
                        request.grant(granted);
                    } else {
                        pendingWebPerm = request;
                        pendingWebRes = granted;
                        ActivityCompat.requestPermissions(MainActivity.this, missing.toArray(new String[0]), PERM_REQ);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (!ALLOW_GEO) {
                    cb.invoke(origin, false, false);
                    return;
                }
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    cb.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCb = cb;
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, GEO_REQ);
                }
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                ((FrameLayout) getWindow().getDecorView()).addView(view,
                        new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                applyUi(true);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                ((FrameLayout) getWindow().getDecorView()).removeView(customView);
                customView = null;
                if (customCb != null) customCb.onCustomViewHidden();
                customCb = null;
                applyUi(IMMERSIVE);
            }
        };
        web.setWebChromeClient(chrome);

        if (saved != null) web.restoreState(saved);
        else web.loadUrl(START_URL);
    }

    private boolean route(Uri u) {
        String scheme = u.getScheme();
        if (scheme == null) return false;
        if (ASSET_HOST.equals(u.getHost())) return false;
        if (scheme.equals("about") || scheme.equals("data") || scheme.equals("blob")
                || scheme.equals("javascript") || scheme.equals("file")) return false;
        boolean web = scheme.equals("http") || scheme.equals("https");
        if (!web || OPEN_EXTERNAL) {
            openExternal(u);
            return true;
        }
        return false;
    }

    private void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException e) {
            toast("No hay ninguna app para abrir este enlace");
        }
    }

    private void showError() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;text-align:center;padding:48px 24px;color:#333'>"
                + "<h2>Sin conexi&oacute;n</h2><p>No se pudo cargar la p&aacute;gina.</p>"
                + "<button style='padding:12px 20px;font-size:16px' onclick='history.go(-2)'>Volver</button>"
                + "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private void applyUi(boolean immersive) {
        View d = getWindow().getDecorView();
        int f = baseUiFlags;
        if (immersive) {
            f |= View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        d.setSystemUiVisibility(f);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && IMMERSIVE) applyUi(true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        boolean ok = results.length > 0;
        for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        if (code == PERM_REQ && pendingWebPerm != null) {
            if (ok) pendingWebPerm.grant(pendingWebRes);
            else pendingWebPerm.deny();
            pendingWebPerm = null;
        }
        if (code == GEO_REQ && pendingGeoCb != null) {
            pendingGeoCb.invoke(pendingGeoOrigin, ok, false);
            pendingGeoCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            chrome.onHideCustomView();
            return;
        }
        if (web.canGoBack()) {
            web.goBack();
            return;
        }
        if (DOUBLE_BACK_EXIT) {
            long now = System.currentTimeMillis();
            if (now - lastBack < 2000) {
                super.onBackPressed();
            } else {
                lastBack = now;
                toast("Pulsa de nuevo para salir");
            }
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }

    /** Funciones nativas disponibles en JavaScript como window.AndroidApp */
    private class Bridge {
        @JavascriptInterface
        public void toast(final String m) {
            runOnUiThread(() -> MainActivity.this.toast(m));
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) v.vibrate(Math.max(1, Math.min(ms, 2000)));
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, null));
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> openExternal(Uri.parse(url)));
        }

        @JavascriptInterface
        public void exit() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public String version() {
            return APP_VERSION;
        }
    }
}
